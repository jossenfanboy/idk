
# Discord Gen Bot

A Discord Bot That Help You To Item Distribution Like Keys And Perks


## How To Use

 - [Youtube Video](https://www.youtube.com/watch?v=wWuAxfo8bWc)

## How To Configure

#### Upload All Files On Host
#### Configure All Settings In **Index.js**
#### Add TOKEN You Your Bot In .**env** (secrets)
#### That's It 
See Video For More Information [Video](https://www.youtube.com/watch?v=wWuAxfo8bWc)



## Gen Bot Not Responding (Only Responding In Dms)

![App Screenshot](https://cdn.discordapp.com/attachments/1080667689820897340/1080789867761504320/image.png)


## Authors

- [@ScienceGear](https://www.github.com/ScienceGear)


![Logo](https://cdn.discordapp.com/attachments/1015552073753960479/1080796302662709258/GEN-Bot-3-2-2023.png)

